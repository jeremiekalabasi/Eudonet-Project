﻿using System;
using EudonetOffice.Services;
using EudoBackEnd.Repository;
using Microsoft.AspNetCore.Mvc;

namespace EudonetOffice.Controllers
{
    /// <summary>
    /// 
    /// </summary>
	public class RestaurantController : Controller
	{

        RestaurantServices _restaurantService = new RestaurantServices() ;
        MealRestaurantServices _mealRestaurantService = new MealRestaurantServices();

		public RestaurantController()
		{
		}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ViewResult Index()
        {
            var restaurants = _restaurantService.getRestaurant();
            ViewData.Model = restaurants; 


            return View();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult List(int idRestaurant)
        {
            var restaurants = _mealRestaurantService.getMealRestaurant(idRestaurant);
            ViewData.Model = restaurants;
            ViewBag.RestaurantName = _restaurantService.get(idRestaurant).Name; 

            return View();

        }

    }
}

