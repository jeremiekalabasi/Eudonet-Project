﻿using System;
using EudonetOffice.Models;
using EudonetOffice.Services;
using Microsoft.AspNetCore.Mvc;

namespace EudonetOffice.Controllers
{
    /// <summary>
    /// 
    /// </summary>
	public class MealRestaurantController : Controller
	{

        MealRestaurantServices _mealRestaurantService = new MealRestaurantServices();

        public MealRestaurantController()
		{
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_mealRestaurant"></param>
		public void AddMeal(MealRestaurant _mealRestaurant)
		{
            if(_mealRestaurant.Name != null )
            {
                _mealRestaurantService.addMealRestaurant(_mealRestaurant);
            }

		}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult AddNewMeal()
        {	

            return View();

        }




    }
}

