﻿using System;
namespace EudonetOffice.Controllers
{
	/// <summary>
	/// 
	/// </summary>
	public class MealController
	{
		public MealController()
		{
		}
	}
}

