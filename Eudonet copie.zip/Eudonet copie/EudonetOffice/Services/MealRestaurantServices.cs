﻿using System;
using EudonetOffice.Models;
using EudoBackEnd.Repository;

namespace EudonetOffice.Services
{
    /// <summary>
    /// MealRestaurant services
    /// </summary>
	public class MealRestaurantServices
	{
        MealRestaurantRepository mealRestaurantRepository = new MealRestaurantRepository();

        public MealRestaurantServices()
        {

        }

        /// <summary>
        /// Get the restaurant meals with the idRestaurant in parameter
        /// </summary>
        /// <returns></returns>
        public List<MealRestaurant> getMealRestaurant(int idRestaurant)
        {
            List<MealRestaurant> mealRestaurants = mealRestaurantRepository.GetAll().Where(e => e.IdRestaurant == idRestaurant).Select(e => new MealRestaurant { ID = e.ID, Name = e.Name, IdMeal = e.IdMeal, IdRestaurant = e.IdRestaurant }).ToList();

            return mealRestaurants;
        }

        /// <summary>
        /// Add a Meal to a restaurant
        /// </summary>
        /// <param name="_mealRestaurant"></param>
        public void addMealRestaurant(MealRestaurant _mealRestaurant)
        {

            EudoBackEnd.Models.MealRestaurant mealRestaurantService =
                new EudoBackEnd.Models.MealRestaurant
                {
                    Name = _mealRestaurant.Name,
                    IdMeal = _mealRestaurant.IdMeal,
                    IdRestaurant = _mealRestaurant.IdRestaurant
                };

            mealRestaurantRepository.Insert(mealRestaurantService);
            mealRestaurantRepository.Save();
        }


    }
}

