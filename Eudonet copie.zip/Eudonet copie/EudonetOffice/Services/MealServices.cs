﻿using System;
using EudoBackEnd;
using EudoBackEnd.Repository; 
namespace EudonetOffice.Services
{
    /// <summary>
    /// Meal services
    /// </summary>
    public class MealServices
    {
        //private IEudoServices _instance;
        MealRepository mealRepository = new MealRepository();
        EudoBackEnd.EudoServices eudoServices = new EudoBackEnd.EudoServices();

        /// <summary>
        /// 
        /// </summary>
        public MealServices()
        {

        }

        /// <summary>
        /// List the Meal begin by parameters "lettre"
        /// </summary>
        /// <param name="lettre"></param>
        public void ListAllMealsByFirstLetter(string lettre)
        {
            var res = eudoServices.ListAllMealsByFirstLetter(lettre);

            List<EudonetOffice.Models.Meal> retour = res.Select(e => new EudonetOffice.Models.Meal { ID = e.id , Name = e.strMeal, strImageSource = e.strImageSource }).ToList(); 

        }
    }
}

