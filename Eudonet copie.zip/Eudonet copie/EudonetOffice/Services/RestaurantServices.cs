﻿using System;
using EudonetOffice.Models;
using EudoBackEnd.Repository;
using System.Linq;

namespace EudonetOffice.Services
{
	/// <summary>
	/// Restaurant services
	/// </summary>
	public class RestaurantServices
	{
        RestaurantRepository restaurantRepository = new RestaurantRepository();

		/// <summary>
		/// 
		/// </summary>
        public RestaurantServices()
		{

        }

		/// <summary>
		/// Get all restaurant from db
		/// </summary>
		/// <returns></returns>
		public List<Restaurant> getRestaurant()
		{
            List<Restaurant> restaurants = restaurantRepository.GetAll().Select(e => new Restaurant { ID = e.ID, City = e.City, Name = e.Name}).ToList();

			return restaurants;
        }

		/// <summary>
		/// Get a restaurant with the id
		/// </summary>
		/// <param name="idRestaurant"></param>
		/// <returns></returns>
		public Restaurant get(int idRestaurant)
		{
			EudoBackEnd.Models.Restaurant _restaurantBack = restaurantRepository.Get(idRestaurant);

			Restaurant restaurant = new Restaurant { ID = _restaurantBack.ID, City = _restaurantBack.City, Name = _restaurantBack.Name };

			return restaurant; 
		}

	}
}

