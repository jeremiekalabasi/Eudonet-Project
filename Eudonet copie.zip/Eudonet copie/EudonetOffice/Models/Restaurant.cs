﻿using System;
namespace EudonetOffice.Models
{
	public class Restaurant
	{
		/// <summary>
		/// 
		/// </summary>
        public int ID { get; set; }

		/// <summary>
		/// 
		/// </summary>
        public string Name { get; set; }

		/// <summary>
		/// 
		/// </summary>
        public string City { get; set; }


		/// <summary>
		/// 
		/// </summary>
        public Restaurant()
		{
		}
	}
}

