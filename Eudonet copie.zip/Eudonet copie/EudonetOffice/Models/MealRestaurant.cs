﻿using System;
namespace EudonetOffice.Models
{
	public class MealRestaurant
	{
        /// <summary>
        /// 
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int IdRestaurant { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int IdMeal { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public MealRestaurant()
		{

		}
	}
}

