﻿using System;
namespace EudonetOffice.Models
{
	public class Meal
	{
		/// <summary>
		/// 
		/// </summary>
        public int ID { get; set; }

		/// <summary>
		/// 
		/// </summary>
        public string Name { get; set; }

		/// <summary>
		/// 
		/// </summary>
        public string strImageSource { get; set; }

        public Meal()
		{
		}
	}
}

