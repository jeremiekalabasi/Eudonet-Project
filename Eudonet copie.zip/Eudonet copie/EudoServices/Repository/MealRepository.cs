﻿using System;
using EudoBackEnd.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Protocols;
using System.Configuration;

namespace EudoBackEnd.Repository
{
    /// <summary>
    /// Meal Repository
    /// </summary>
    public class MealRepository : IMealRepository
    {
        string keyvalue = ConfigurationManager.AppSettings["connectionstring"];


        private readonly MealDbContext _context;


        public MealRepository()
        {
            _context = new MealDbContext(keyvalue + "");
        }


        public IEnumerable<Meal> GetAll()
        {
            return _context.Meal.ToList();
        }


        public Meal Get(int mealID)
        {
            return _context.Meal.Find(mealID);
        }


        public void Insert(Meal meal)
        {
            
            _context.Meal.Add(meal);
        }
        
        public void Update(Meal meal)
        {
            
            _context.Entry(meal).State = EntityState.Modified;
        }


        public void Delete(int mealID)
        {
            
            Meal meal = _context.Meal.Find(mealID);
            
            if (meal != null)
            {
                
                _context.Meal.Remove(meal);
            }

        }


        public void Save()
        {
            
            _context.SaveChanges();
        }
        private bool disposed = false;
        
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}

