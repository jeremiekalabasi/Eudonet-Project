﻿using System;
using EudoBackEnd.Models;

namespace EudoBackEnd.Repository
{
    /// <summary>
    /// MealRestaurant Interface
    /// </summary>
    public interface IMealRestaurantRepository
    {
        IEnumerable<MealRestaurant> GetAll();
        MealRestaurant Get(int mealRestaurantID);
        void Insert(MealRestaurant mealRestaurant);
        void Delete(int mealRestaurantID);
        void Update(MealRestaurant mealRestaurant);
        void Save();

    }
}

