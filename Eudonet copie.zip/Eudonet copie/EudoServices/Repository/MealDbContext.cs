﻿using System;
using System.Configuration;
using EudoBackEnd.Models;
using Microsoft.EntityFrameworkCore;

namespace EudoBackEnd.Repository
{
    /// <summary>
    /// DBContext for the repository
    /// </summary>
	public class MealDbContext : DbContext
	{
        string _conn = ""; 
        public MealDbContext(string conn)
        {
            _conn = conn; 
        }

        public MealDbContext(DbContextOptions<MealDbContext> options) : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_conn);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }
        public DbSet<Restaurant> Restaurant { get; set; }
        public DbSet<Meal> Meal { get; set; }
        public DbSet<MealRestaurant> MealRestaurant { get; set; }
    }
}

