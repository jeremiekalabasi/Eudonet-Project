﻿using System;
using EudoBackEnd.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Protocols;
using System.Configuration;

namespace EudoBackEnd.Repository
{
    /// <summary>
    /// Restaurant Repository
    /// </summary>
	public class RestaurantRepository : IRestaurantRepository
    {
        string keyvalue = ConfigurationManager.AppSettings["keyname"];

        
        private readonly MealDbContext _context;

        
        public RestaurantRepository()
        {
            string keyvalue = "server = localhost; User Id = SA;Persist Security info = True; database = MEAL_DB; Password = Password.1;MultipleActiveResultSets=True;MultiSubnetFailover=True;TrustServerCertificate=True";
            _context = new MealDbContext(keyvalue+"");
        } 

        
        public IEnumerable<Restaurant> GetAll()
        { 
            return _context.Restaurant.ToList();
        }


        public Restaurant Get(int RestaurantID)
        {
            return _context.Restaurant.Find(RestaurantID);
        }


        public void Insert(Restaurant restaurant)
        {
            
            _context.Restaurant.Add(restaurant);
        }

        public void Update(Restaurant restaurant)
        {
            _context.Entry(restaurant).State = EntityState.Modified;
        }

        public void Delete(int RestaurantID)
        {
            Restaurant restaurant = _context.Restaurant.Find(RestaurantID);

            if (restaurant != null)
            {
                _context.Restaurant.Remove(restaurant);
            }

        }

        public void Save()
        {
            _context.SaveChanges();
        }
        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}

