﻿using System;
using EudoBackEnd.Models;

namespace EudoBackEnd.Repository
{
    /// <summary>
    /// MealRepository interface
    /// </summary>
    public interface IMealRepository
    {
        IEnumerable<Meal> GetAll();
        Meal Get(int mealID);
        void Insert(Meal meal);
        void Delete(int mealID);
        void Update(Meal meal);
        void Save();

    }
}

