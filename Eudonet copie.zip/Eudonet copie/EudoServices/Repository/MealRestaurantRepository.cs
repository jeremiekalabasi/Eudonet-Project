﻿using System;
using EudoBackEnd.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Protocols;
using System.Configuration;

namespace EudoBackEnd.Repository
{
    /// <summary>
    /// MealRestaurant repository
    /// </summary>
    public class MealRestaurantRepository : IMealRestaurantRepository
    {
        string keyvalue = ConfigurationManager.AppSettings["connectionstring"];

       
        private readonly MealDbContext _context;

        
        public MealRestaurantRepository()
        {
            _context = new MealDbContext(keyvalue + "");
        }

        
        public IEnumerable<MealRestaurant> GetAll()
        {
            return _context.MealRestaurant.ToList();
        }

        public MealRestaurant Get(int mealRestaurantID)
        {
            return _context.MealRestaurant.Find(mealRestaurantID);
        }


        public void Insert(MealRestaurant mealRestaurant)
        {
            
            _context.MealRestaurant.Add(mealRestaurant);
        }


        public void Update(MealRestaurant mealRestaurant)
        {
            
            _context.Entry(mealRestaurant).State = EntityState.Modified;
        }


        public void Delete(int mealRestaurantID)
        {
            
            MealRestaurant mealRestaurant = _context.MealRestaurant.Find(mealRestaurantID);
            if (mealRestaurant != null)
            {
                
                _context.MealRestaurant.Remove(mealRestaurant);
            }

        }

        public void Save()
        {

            _context.SaveChanges();
        }
        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}

