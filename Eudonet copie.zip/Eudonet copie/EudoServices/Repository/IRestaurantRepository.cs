﻿using System;
using EudoBackEnd.Models;

namespace EudoBackEnd.Repository
{
    /// <summary>
    /// Restaurant interface
    /// </summary>
	public interface IRestaurantRepository
    {
        IEnumerable<Restaurant> GetAll();
        Restaurant Get(int restaurantID);
        void Insert(Restaurant restaurant);
        void Delete(int restaurantID);
        void Update(Restaurant restaurant);
        void Save();

    }
}

