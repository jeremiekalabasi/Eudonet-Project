﻿using System;
namespace EudoBackEnd.Models
{
	public class Restaurant
	{
			/// <summary>
			/// Restaurant model
			/// </summary>
			public int ID { get; set;  }
			public string Name { get; set;  }
			public string City { get; set; }

	}
}

