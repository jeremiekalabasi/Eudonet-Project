﻿using System;
namespace EudoBackEnd.Models
{
	/// <summary>
	/// MealRestaurant Model
	/// </summary>
	public class MealRestaurant
	{
		public int ID { get; set;  }

		public string Name { get; set; }

		public int IdRestaurant { get; set; }

		public int IdMeal { get; set; }
	}
}

