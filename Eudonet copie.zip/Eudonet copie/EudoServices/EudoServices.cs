﻿using System;
using System.Collections.Generic;
using EudoBackEnd.Models;
using RestSharp;

namespace EudoBackEnd
{
    /// <summary>
    /// Service use to connect and get data from TheMealDB
    /// </summary>
	public class EudoServices : IEudoServices
    {
        public EudoServices()
        {
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="lettre"></param>
        /// <returns></returns>
		public List<Meal> ListAllMealsByFirstLetter(string lettre)
        {
            var client = new RestClient("www.themealdb.com");
            var request = new RestRequest("/api/json/v1/1/search.php?s="+lettre, Method.Get);

            Meals queryResult = client.Execute<Meals>(request).Data;

            return queryResult!= null ? queryResult.meals : null;
        
        }



    }
}

