﻿using System;
//using DataBaseConnection.Connection;

namespace EudoBackEnd.Controllers
{
	public class Restaurant
	{
		public Restaurant()
		{
        }

		public List<Restaurant> getListRestaurant()
		{
			List<Restaurant> restaurants = new List<Restaurant>();

			//restaurants.AddRange(con)

			return restaurants;
		}
	}
}

