﻿using System;
//using DataBaseConnection.Connection;

namespace EudoBackEnd.Controllers
{
	public class Meal
	{
		
        public Meal()
		{
        }




		//public GetList
	}
}

