﻿using EudoBackEnd.Models;

namespace EudoBackEnd;

/// <summary>
/// EudoServices interface
/// </summary>
public interface IEudoServices
{
    public List<Meal> ListAllMealsByFirstLetter(string lettre);
}

